<h1 align="center">
  <br>
  <a href="https://github.com/ultrasecurity/Storm-Breaker"><img src=".imgs/1demo.png" alt="StormBreaker"></a>

</h1>

<h4 align="center">A tool with attractive capabilities</h4>

<p align="center">
  <a href="http://python.org">
    <img src="https://img.shields.io/badge/python-v3-blue">
  </a>
  <a href="https://php.net">
    <img src="https://img.shields.io/badge/php-7.4.4-green"
         alt="php">
  </a>

  <a href="https://www.microsoft.com/de-de/">
    <img src="https://img.shields.io/badge/platform-Linux-red">
  </a>
</p>

![demo](.imgs/Work0.png)

### Features:

- Get Device Information Without Any Permissions
- Access Location [SMARTPHONES]
- Access Webcam
- Access Microphone



### Update Log:
- Second(latest) Update in  May 18, 2022
- The overall structure of the tool is programmed from scratch
- Previous versions bugs fixed
- Added auto-download ngrok

> We have deleted ngrok in the new version of storm breaker and entrusted the user with run and share the localhost. So please note that storm breaker runs a localhost for you and you have to start the ngrok on your intended port yourself.


### Dependencies

**`Storm Breaker`** requires following programs to run properly - 
- `php`
- `neofetch`
- `python3`
- `git`
- `ngrok`

![demo](.imgs/Work3.gif)

### Operating Systems Tested

- Kali Linux 2022
- macOS Big Sur / M1 

### Installation On Kali Linux


```bash
$ git clone https://github.com/ultrasecurity/Storm-Breaker
$ cd Storm-Breaker
$ sudo bash install.sh
$ sudo python3 -m pip install -r requirements.txt
$ sudo python3 st.py
```


<h3 align="center">
:: Workflow ::

</h3>
<p align="center">
<img src=".imgs/Work1.png"/>
  
<br>
<img src=".imgs/Work2.png"/>

 
</p>
