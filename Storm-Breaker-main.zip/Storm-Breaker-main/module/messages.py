def show_message(msg):
    if msg == "loc":
        return "Waiting for User Interaction"
    
    elif msg == "mic":
        return "Waiting to receive victim Voice"

    elif msg == "webcam":
        return "Waiting to receive victim Picture"
    